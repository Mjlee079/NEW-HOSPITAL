/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author wisdom
 */
import java.sql.*;


class DbConnection {
    Connection con = null;
    
    public static Connection ConnectionDB(){
        
        try{
            Class.forName("org.sqlite.JDBC");
            Connection con = DriverManager.getConnection("jdbc:sqlite:login.db");
            System.out.println("Connection succeded");
            return con;
        }
        catch(Exception e){
            System.out.println("Connection Faliled" + e);
            return null;
        }
    }
    
}
